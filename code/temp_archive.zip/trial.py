import torch
import torch.nn as nn
import torch.optim as optim
import run_websocket_client

model = run_websocket_client.ConvNet1D(input_size=400, num_classes=7)

model_path = r'E:\2023mem\Python-PJ\fl-experiment\code3\HAR_1d_cnn.pt'
checkpoint = torch.load(model_path)

model.load_state_dict(checkpoint)
traced_model = torch.jit.trace(model, torch.zeros([1, 400, 3], dtype=torch.float))

model.train()
optimizer = optim.SGD(model.parameters(), lr=0.001)



